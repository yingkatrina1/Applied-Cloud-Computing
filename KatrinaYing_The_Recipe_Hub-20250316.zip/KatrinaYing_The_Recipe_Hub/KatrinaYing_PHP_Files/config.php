<?php
$servername = "localhost";
$username = "root"; // Replace with MySQL user if different
$password = "cloud"; //  MySQL root password
$dbname = "recipe_db"; //  database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
