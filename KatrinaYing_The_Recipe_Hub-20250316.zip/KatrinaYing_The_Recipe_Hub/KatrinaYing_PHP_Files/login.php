<?php
include('config.php'); // Include database connection file

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username']; // Get entered username
    $password = $_POST['password']; // Get entered password

    // Prepare SQL query using prepared statements to avoid SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username); // "s" indicates the type is string
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User exists
        $user = $result->fetch_assoc();
        // Verify the entered password with the stored hashed password
        if (password_verify($password, $user['password_hash'])) {
            // Password is correct, start the session and store the user's information
            session_start();
            $_SESSION['user_id'] = $user['user_id']; // Store user_id in session
            $_SESSION['username'] = $user['username']; // Store username in session

            // Redirect to index.php (homepage)
            header("Location: index.php"); // Redirect to the homepage
            exit(); // Make sure no further code is executed after the redirect
        } else {
            echo "Invalid password."; // If password does not match
        }
    } else {
        echo "No user found."; // If user does not exist
    }

    $stmt->close(); // Close the prepared statement
    $conn->close(); // Close database connection
}
?>

<!-- Login form -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Recipe Sharing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 20px;
        }

        label {
            font-size: 16px;
            color: #555;
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        .error-message {
            color: #e74c3c;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .signup-link {
            text-align: center;
            margin-top: 20px;
        }

        .signup-link a {
            color: #3498db;
            text-decoration: none;
            font-weight: bold;
        }

        .signup-link a:hover {
            color: #2980b9;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login to Recipe Sharing</h2>

    <!-- Show error message if login fails -->
    <?php if (isset($error_message)): ?>
        <p class="error-message"><?php echo $error_message; ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <label for="username">Username:</label>
        <input type="text" name="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <input type="submit" value="Login">
    </form>

    <div class="signup-link">
        <p>Don't have an account? <a href="register.php">Register Here</a></p>
    </div>
</div>

</body>
</html>
