<?php
include('config.php'); // Include database connection file
session_start(); // Start session to check if the user is logged in

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to add a recipe.";
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debug: Output the POST data to check if everything is received
    // var_dump($_POST);

    // Get recipe title, description, instructions, and user_id from the session
    $title = $_POST['title']; // Get recipe title from form input
    $description = $_POST['description']; // Get recipe description from form input
    $instructions = $_POST['instructions']; // Get recipe instructions from form input
    $user_id = $_SESSION['user_id']; // Get the user ID from the session

    // Debug: Check if values are set and not empty
    if (empty($title) || empty($description) || empty($instructions)) {
        echo "Title, description, or instructions is empty.";
        exit;
    }

    // Insert recipe into the database using prepared statements to avoid SQL injection
    $sql = $conn->prepare("INSERT INTO recipes (user_id, title, description, recipe_instructions) VALUES (?, ?, ?, ?)");
    $sql->bind_param("isss", $user_id, $title, $description, $instructions);

    if ($sql->execute()) {
        $recipe_id = $conn->insert_id; // Get the ID of the newly inserted recipe

        // Debug: Check if recipe is inserted
        echo "Recipe inserted successfully with ID: " . $recipe_id;

        // Insert ingredients into the database
        if (isset($_POST['ingredient_name']) && isset($_POST['ingredient_quantity'])) {
            $ingredient_names = $_POST['ingredient_name'];
            $ingredient_quantities = $_POST['ingredient_quantity'];

            foreach ($ingredient_names as $index => $ingredient_name) {
                $ingredient_quantity = $ingredient_quantities[$index];

                // Insert ingredients using prepared statements
                $sql_ingredients = $conn->prepare("INSERT INTO ingredients (recipe_id, ingredient_name, quantity) VALUES (?, ?, ?)");
                $sql_ingredients->bind_param("iss", $recipe_id, $ingredient_name, $ingredient_quantity);

                if (!$sql_ingredients->execute()) {
                    echo "Error inserting ingredient: " . $conn->error;
                } else {
                    // Debug: Check if ingredient is inserted
                    echo "Ingredient inserted: " . $ingredient_name;
                }
            }
        }

        // Redirect to index.php after successful recipe submission
        header("Location: index.php");  // Redirect to the main page with the updated recipe
        exit(); // Don't forget to exit after header to prevent further code execution
    } else {
        // Debug: Output error if the recipe insertion fails
        echo "Error inserting recipe: " . $conn->error;
    }
}

$conn->close(); // Close database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Recipe</title>
    <style>
        /* Add some basic styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center; /* center heading */
        }

        form {
            width: 60%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form input[type="submit"] {
	    display: block;
	    margin: 20px auto;
            background-color: #2980b9;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        form input[type="submit"]:hover {
            background-color: #3498db;
        }

        .ingredient-group {
            margin-bottom: 10px;
        }

        .remove-btn {
            background-color: red;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 14px;
            padding: 5px 10px;
            margin-top: 5px;
        }

        .remove-btn:hover {
            background-color: darkred;
        }

        .back-btn {
            margin-top: 20px;
            background-color: #808080;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            display: block;
            margin-left: auto;
            margin-right: auto;
	    width: fit-content;
        }

        .back-btn:hover {
            background-color: #7f8c8d;
        }

        h4 {
            font-weight: bold; /* Bold the instructions header */
        }
    </style>
</head>
<body>

<!-- Add Recipe Form -->
<div>
    <h1>Add a New Recipe</h1>
    <form method="POST" action="add_recipe.php">
        <label for="title">Recipe Title:</label>
        <input type="text" name="title" id="title" required>

        <label for="description">Recipe Description:</label>
        <textarea name="description" id="description" rows="5" required></textarea>

        <h3>Ingredients</h3>
        <div id="ingredients">
            <div class="ingredient-group">
                <label for="ingredient_name">Ingredient:</label>
                <input type="text" name="ingredient_name[]" placeholder="Ingredient Name" required><br>
                <label for="ingredient_quantity">Quantity:</label>
                <input type="text" name="ingredient_quantity[]" placeholder="Quantity" required><br>
                <button type="button" class="remove-btn" onclick="removeIngredient(this)">Remove Ingredient</button>
            </div>
        </div>
        <button type="button" onclick="addIngredient()">Add Another Ingredient</button>

        <h3>Instructions</h3>
        <textarea name="instructions" id="instructions" rows="5" required></textarea>

        <input type="submit" value="Add Recipe">
    </form>

    <!-- Back to Home Button -->
    <a href="index.php" class="back-btn">Back to Home</a>
</div>

<script>
    // Function to add new ingredient fields
    function addIngredient() {
        var ingredientsDiv = document.getElementById("ingredients");
        var newIngredient = document.createElement("div");
        newIngredient.classList.add("ingredient-group");
        newIngredient.innerHTML = `
            <label for="ingredient_name">Ingredient:</label>
            <input type="text" name="ingredient_name[]" placeholder="Ingredient Name" required><br>
            <label for="ingredient_quantity">Quantity:</label>
            <input type="text" name="ingredient_quantity[]" placeholder="Quantity" required><br>
            <button type="button" class="remove-btn" onclick="removeIngredient(this)">Remove Ingredient</button>
        `;
        ingredientsDiv.appendChild(newIngredient);
    }

    // Function to remove ingredient fields
    function removeIngredient(button) {
        var ingredientGroup = button.parentElement;
        ingredientGroup.remove(); // Remove the corresponding ingredient group
    }
</script>

</body>
</html>
