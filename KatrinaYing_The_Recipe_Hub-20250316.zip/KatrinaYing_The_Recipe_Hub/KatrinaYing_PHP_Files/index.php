<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Recipe Hub</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 24px;
        }

        header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 220px; /* Reduced size */
            height: 250px; /* Reduced height */
            margin: 10px;
            display: inline-block;
            text-align: center;
            vertical-align: top;
            overflow: hidden; /* Prevents overflow */
        }

        .recipe-title {
            font-size: 18px;
            color: #2c3e50;
            margin-bottom: 10px;
            word-wrap: break-word; /* Allows long titles to wrap */
        }

        .recipe-description {
            font-size: 14px;
            color: #555;
            height: 100px;
            overflow-y: auto; /* Makes long descriptions scrollable */
        }

        .btn-container {
            margin-top: 10px;
        }

        .btn {
            display: inline-block;
            margin: 5px;
            padding: 8px 16px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            transition: 0.3s ease;
        }

        .btn:hover {
            background-color: #2980b9;
        }

        .btn-secondary {
            background-color: #e74c3c;
        }

        .btn-secondary:hover {
            background-color: #c0392b;
        }

        /* Recipe container to be scrollable */
        .recipe-container {
            text-align: center;
            margin: 20px auto;
            max-width: 1200px;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            max-height: 600px; /* Set a max height */
            overflow-y: auto; /* Enable scrolling */
        }

        .header-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #34495e;
            color: white;
        }

        .header-bar a {
            color: white;
            text-decoration: none;
            margin-left: 10px;
            font-weight: bold;
        }

        /* Center Add Recipe Button */
        .add-recipe-btn {
            text-align: center;
            margin: 20px;
        }

        .add-recipe-btn a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #16a085; /* Muted blue-green color */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 18px;
            transition: 0.3s ease;
        }

        .add-recipe-btn a:hover {
            background-color: #1abc9c; /* Lighter shade of blue-green */
        }
    </style>
</head>
<body>

<header class="header-bar">
    <div>
        <h2>Welcome to The Recipe Hub!</h2>
    </div>
    <div>
        <?php if (isset($_SESSION['user_id'])): ?>
            <span>Hello, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
            <a href="logout.php" class="btn btn-secondary">Logout</a>
        <?php else: ?>
            <span>Welcome!</span>
            <a href="login.php" class="btn">Register or Login</a>
        <?php endif; ?>
    </div>
</header>

<div class="recipe-container">
    <?php
    // Fetch all recipes
    $sql = "SELECT * FROM recipes";
    $result = $conn->query($sql);

    if ($result->num_rows > 0):
        while ($recipe = $result->fetch_assoc()):
    ?>
        <div class="container">
            <h3 class="recipe-title"><?php echo htmlspecialchars($recipe['title']); ?></h3>
            <p class="recipe-description"><?php echo nl2br(htmlspecialchars($recipe['description'])); ?></p>
            <div class="btn-container">
                <a href="view_recipe.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn">View Recipe</a>
            </div>
        </div>
    <?php endwhile; endif; ?>
</div>

<?php if (isset($_SESSION['user_id'])): ?>
    <div class="add-recipe-btn">
        <a href="add_recipe.php" class="btn">Add Recipe</a>
    </div>
<?php endif; ?>

</body>
</html>

<?php $conn->close(); ?>
