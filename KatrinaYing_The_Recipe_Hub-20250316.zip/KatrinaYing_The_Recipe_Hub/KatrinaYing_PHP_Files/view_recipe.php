<?php
include('config.php');
session_start();

$recipe_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user_id = $_SESSION['user_id'] ?? null;

// Fetch recipe details along with the username of the user who created it
$sql = "SELECT recipes.*, users.username 
        FROM recipes 
        JOIN users ON recipes.user_id = users.user_id 
        WHERE recipe_id='$recipe_id'";
$result = $conn->query($sql);
$recipe = $result->fetch_assoc();

if (!$recipe) {
    echo "Recipe not found.";
    exit;
}

// Fetch ingredients
$sql_ingredients = "SELECT * FROM ingredients WHERE recipe_id='$recipe_id'";
$ingredients = $conn->query($sql_ingredients);

// Fetch ratings for the recipe
$sql_ratings = "SELECT ratings.*, users.username 
                FROM ratings 
                JOIN users ON ratings.user_id = users.user_id 
                WHERE recipe_id='$recipe_id'";
$ratings = $conn->query($sql_ratings);

// Check if user owns the recipe
$is_owner = $user_id && $user_id == $recipe['user_id'];

// Check if the logged-in user has already rated the recipe
$sql_user_rating = "SELECT * FROM ratings WHERE recipe_id='$recipe_id' AND user_id='$user_id'";
$user_rating_result = $conn->query($sql_user_rating);
$user_has_rated = $user_rating_result->num_rows > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($recipe['title']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 50%;
            text-align: center;
        }
        h1 { color: #2c3e50; font-size: 24px; }
        p { font-size: 16px; color: #555; }
        .ingredients, .instructions, .ratings {
            text-align: left;
            margin-top: 20px;
            padding: 10px;
            background: #ecf0f1;
            border-radius: 5px;
        }
        .ratings .rating {
            background: #d0e7f9;
            padding: 8px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .btn-container { margin-top: 20px; }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn:hover { background-color: #2980b9; }
        .btn-secondary { background-color: #95a5a6; }
        .btn-secondary:hover { background-color: #7f8c8d; }
        .btn-edit-rating {
            background-color: #f39c12; /* Orange for edit button */
            margin-left: 10px;
        }
        .btn-edit-rating:hover { background-color: #e67e22; }
        .btn-danger {
            background-color: #e74c3c;
        }
        .btn-danger:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

<div class="container">
    <h1><?php echo htmlspecialchars($recipe['title']); ?></h1>
    <p><strong>Created by:</strong> <?php echo htmlspecialchars($recipe['username']); ?></p>
    <p><?php echo nl2br(htmlspecialchars($recipe['description'])); ?></p>

    <div class="ingredients">
        <h3>Ingredients</h3>
        <ul>
            <?php while ($ingredient = $ingredients->fetch_assoc()): ?>
                <li><?php echo htmlspecialchars($ingredient['quantity']) . " - " . htmlspecialchars($ingredient['ingredient_name']); ?></li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div class="instructions">
        <h3>Instructions</h3>
        <p><?php echo nl2br(htmlspecialchars($recipe['recipe_instructions'])); ?></p>
    </div>

    <div class="ratings">
        <h3>Ratings</h3>
        <?php if ($ratings->num_rows > 0): ?>
            <?php while ($rating = $ratings->fetch_assoc()): ?>
                <div class="rating">
                    <strong><?php echo htmlspecialchars($rating['username']); ?></strong> - 
                    Rating: <?php echo htmlspecialchars($rating['rating']); ?> / 5
                    <p><?php echo nl2br(htmlspecialchars($rating['comment'])); ?></p>
                    
                    <!-- Show "Edit Rating" button only for the logged-in user who left this rating -->
                    <?php if ($user_id && $user_id == $rating['user_id']): ?>
                        <a href="submit_rating.php?id=<?php echo $recipe_id; ?>" class="btn btn-edit-rating">Edit Rating</a>
                        <a href="submit_rating.php?id=<?php echo $recipe_id; ?>&delete=true&rating_id=<?php echo $rating['rating_id']; ?>" class="btn btn-danger">Delete Rating</a>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No ratings yet.</p>
        <?php endif; ?>
    </div>

    <div class="btn-container">
        <?php if ($is_owner): ?>
            <a href="edit_recipe.php?id=<?php echo $recipe_id; ?>" class="btn">Edit Recipe</a>
        <?php else: ?>
            <!-- Show "Rate Recipe" button only if the user is NOT the creator and hasn't rated yet -->
            <?php if ($user_id && !$is_owner && !$user_has_rated): ?>
                <a href="submit_rating.php?id=<?php echo $recipe_id; ?>" class="btn">Rate Recipe</a>
            <?php endif; ?>
        <?php endif; ?>
        
        <a href="index.php" class="btn btn-secondary">Back to Home</a>
    </div>
</div>

</body>
</html>

<?php $conn->close(); ?>


