<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include('config.php');
session_start();

// Get recipe ID from the URL
$recipe_id = $_GET['id'];

// Fetch recipe details
$sql = "SELECT * FROM recipes WHERE recipe_id='$recipe_id'";
$result = $conn->query($sql);
$recipe = $result->fetch_assoc();

// If recipe not found or user is not the owner, show an error
if (!$recipe || $_SESSION['user_id'] != $recipe['user_id']) {
    echo "You are not authorized to edit this recipe.";
    exit;
}

// Fetch ingredients for the recipe
$sql_ingredients = "SELECT * FROM ingredients WHERE recipe_id='$recipe_id'";
$ingredients = $conn->query($sql_ingredients);
$ingredient_list = [];
while ($ingredient = $ingredients->fetch_assoc()) {
    $ingredient_list[] = $ingredient;
}

// Handle form submission for updating recipe
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title']; // Get recipe title from form input
    $description = $_POST['description']; // Get recipe description from form input
    $recipe_instructions = $_POST['recipe_instructions']; // Get recipe instructions from form input

    // Update recipe in the database
    $sql_update_recipe = "UPDATE recipes SET title='$title', description='$description', recipe_instructions='$recipe_instructions' WHERE recipe_id='$recipe_id'";
    $conn->query($sql_update_recipe);

    // Remove existing ingredients from the database before updating
    $sql_remove_ingredients = "DELETE FROM ingredients WHERE recipe_id='$recipe_id'";
    $conn->query($sql_remove_ingredients);

    // Add updated ingredients
    if (isset($_POST['ingredient_name']) && isset($_POST['quantity'])) {
        $ingredient_names = $_POST['ingredient_name'];
        $ingredient_quantities = $_POST['quantity'];  // Use 'quantity' instead of 'ingredient_quantity'

        // Ensure both arrays have the same number of elements
        $num_ingredients = count($ingredient_names);
        for ($i = 0; $i < $num_ingredients; $i++) {
            // Make sure to check if both the name and quantity are non-empty
            if (!empty($ingredient_names[$i]) && !empty($ingredient_quantities[$i])) {
                $ingredient_name = $ingredient_names[$i];
                $ingredient_quantity = $ingredient_quantities[$i];
                $sql_ingredients = "INSERT INTO ingredients (recipe_id, ingredient_name, quantity) 
                                    VALUES ('$recipe_id', '$ingredient_name', '$ingredient_quantity')";
                $conn->query($sql_ingredients);
            }
        }
    }

    // Redirect to the recipe page after updating
    header("Location: view_recipe.php?id=$recipe_id");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Recipe</title>
    <style>
        /* Add some basic styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        form {
            width: 60%;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form input, form textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        form input[type="submit"] {
            background-color: #2980b9;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 16px;
        }

        form input[type="submit"]:hover {
            background-color: #3498db;
        }

        .ingredient-group {
            margin-bottom: 10px;
        }

        .remove-btn {
            background-color: red;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 14px;
            padding: 5px 10px;
            margin-top: 5px;
        }

        .remove-btn:hover {
            background-color: darkred;
        }
	h1 {
    text-align: center;
	}

	/* Back to Recipe button */
        .back-button-container {
            text-align: center;
            margin-top: 20px;
        }

        .back-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2980b9;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background 0.3s;
        }

        .back-button:hover {
            background-color: #3498db;
	}
    </style>
</head>
<body>

<!-- Edit Recipe Form -->
<div>
    <h1>Edit Recipe</h1>
    <form method="POST" action="edit_recipe.php?id=<?php echo $recipe_id; ?>">
        <label for="title">Recipe Title:</label>
        <input type="text" name="title" id="title" value="<?php echo $recipe['title']; ?>" required>

        <label for="description">Recipe Description:</label>
        <textarea name="description" id="description" rows="5" required><?php echo $recipe['description']; ?></textarea>

        <label for="recipe_instructions">Recipe Instructions:</label>
        <textarea name="recipe_instructions" id="recipe_instructions" rows="5" required><?php echo $recipe['recipe_instructions']; ?></textarea>

        <h3>Ingredients</h3>
        <div id="ingredients">
            <?php
            // Display existing ingredients
            foreach ($ingredient_list as $ingredient) {
                echo "<div class='ingredient-group'>
                        <label for='ingredient_name'>Ingredient:</label>
                        <input type='text' name='ingredient_name[]' value='" . $ingredient['ingredient_name'] . "' required><br>
                        <label for='ingredient_quantity'>Quantity:</label>
                        <input type='text' name='quantity[]' value='" . $ingredient['quantity'] . "' required><br>
                        <button type='button' class='remove-btn' onclick='removeIngredient(this)'>Remove Ingredient</button>
                    </div>";
            }
            ?>
        </div>
        <button type="button" onclick="addIngredient()">Add Another Ingredient</button>

        <input type="submit" value="Update Recipe">
    </form>
</div>

<!-- Back to Reecipe Button -->
<div class="back-button-container">
    <a href="view_recipe.php?id=<?php echo $recipe_id; ?>" class="back-button">Back to Recipe</a>
</div>

<script>
    // Function to add new ingredient fields
    function addIngredient() {
        var ingredientsDiv = document.getElementById("ingredients");
        var newIngredient = document.createElement("div");
        newIngredient.classList.add("ingredient-group");
        newIngredient.innerHTML = ` 
            <label for="ingredient_name">Ingredient:</label>
            <input type="text" name="ingredient_name[]" placeholder="Ingredient Name" required><br>
            <label for="ingredient_quantity">Quantity:</label>
            <input type="text" name="quantity[]" placeholder="Quantity" required><br>
            <button type="button" class="remove-btn" onclick="removeIngredient(this)">Remove Ingredient</button>
        `;
        ingredientsDiv.appendChild(newIngredient);
    }

    // Function to remove ingredient fields
    function removeIngredient(button) {
        var ingredientGroup = button.parentElement;
        ingredientGroup.remove(); // Remove the corresponding ingredient group
    }
</script>

</body>
</html>

<?php
$conn->close(); // Close database connection
?>
