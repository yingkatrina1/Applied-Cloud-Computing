<?php
include('config.php');
session_start();

$recipe_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$user_id = $_SESSION['user_id'] ?? null;

// Handle deletion if 'delete' action is requested
if (isset($_GET['delete']) && isset($_GET['rating_id'])) {
    $rating_id = intval($_GET['rating_id']);

    // Delete the rating
    $sql_delete = "DELETE FROM ratings WHERE rating_id = '$rating_id' AND user_id = '$user_id'";
    if ($conn->query($sql_delete) === TRUE) {
        // Redirect to the recipe page after successful deletion
        header("Location: view_recipe.php?id=$recipe_id");
        exit;
    } else {
        echo "Error deleting rating: " . $conn->error;
    }
}

// Handle rating submission or update if no 'delete' action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rating'])) {
    $rating = intval($_POST['rating']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    
    // If the user has already rated this recipe, update the existing rating
    $sql_check = "SELECT * FROM ratings WHERE recipe_id = '$recipe_id' AND user_id = '$user_id'";
    $result = $conn->query($sql_check);
    
    if ($result->num_rows > 0) {
        // Update existing rating
        $sql_update = "UPDATE ratings SET rating = '$rating', comment = '$comment' WHERE recipe_id = '$recipe_id' AND user_id = '$user_id'";
        if ($conn->query($sql_update) === TRUE) {
            // Redirect to the recipe page after successful update
            header("Location: view_recipe.php?id=$recipe_id");
            exit;
        } else {
            echo "Error updating rating: " . $conn->error;
        }
    } else {
        // Insert new rating
        $sql_insert = "INSERT INTO ratings (recipe_id, user_id, rating, comment) VALUES ('$recipe_id', '$user_id', '$rating', '$comment')";
        if ($conn->query($sql_insert) === TRUE) {
            // Redirect to the recipe page after successful submission
            header("Location: view_recipe.php?id=$recipe_id");
            exit;
        } else {
            echo "Error inserting rating: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Recipe</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            width: 50%;
            text-align: center;
        }

        .btn {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #2980b9;
        }

        .btn-danger {
            background-color: #e74c3c;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Rate Recipe</h2>

    <!-- Removed the warning part about deleting the rating -->
    <form method="POST" action="submit_rating.php?id=<?php echo $recipe_id; ?>">
        <label for="rating">Rating (1 to 5):</label>
        <input type="number" id="rating" name="rating" min="1" max="5" required>
        <br>
        <label for="comment">Comment:</label>
        <textarea id="comment" name="comment" required></textarea>
        <br>
        <button type="submit" class="btn">Submit Rating</button>
    </form>
</div>

</body>
</html>

<?php $conn->close(); ?>
